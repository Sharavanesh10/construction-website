document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('signupForm').addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent default form submission

        const form = event.target;
        const formData = new FormData(form);

        // Convert FormData to URLSearchParams
        const searchParams = new URLSearchParams(formData).toString();

        fetch('/signup/houseowner', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded', // Use URL-encoded format
            },
            body: searchParams,
        })
        .then(response => response.text())
        .then(data => {
            alert(data); // Display response message
            if (data.includes('Sign-up successful')) {
                form.reset(); // Reset form on success
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Sign-up failed. Please try again.');
        });
    });
});
