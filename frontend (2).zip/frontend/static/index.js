// Handle the login form submission
document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the default form submission

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Simple validation
    if (username && password) {
        alert(`Logged in with username: ${username}`);
        // Perform the actual login via the server here (not just redirect)
        // Assuming that the server handles the redirection based on user type after a successful login
        this.submit(); // Submit the form to the server
    } else {
        alert('Please fill in all fields.');
    }
});

// Show the sign-up dialog box when the sign-up link is clicked
document.getElementById('signUpLink').addEventListener('click', function(event) {
    event.preventDefault(); // Prevent default link behavior
    document.getElementById('signUpDialog').style.display = 'block';
});

// Handle the dialog box button clicks
document.getElementById('contractorSignUp').addEventListener('click', function() {
    window.location.href = '/signup/contractor';
});

document.getElementById('houseOwnerSignUp').addEventListener('click', function() {
    window.location.href = '/signup/houseowner';
});

// Close the dialog box
document.getElementById('closeDialog').addEventListener('click', function() {
    document.getElementById('signUpDialog').style.display = 'none';
});
